from django.apps import AppConfig


class DatasortappConfig(AppConfig):
    name = 'datasortapp'
